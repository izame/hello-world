package model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import controller.Helper;
import persistence.AmministratoreDao;
import persistence.EsameDao;
import persistence.MedicoDao;
import persistence.PazienteDao;
import persistence.TipologiaEsameDao;

public class Main{

	public static void main(String[] args) {
		
	
//				//Clinica clinica = new Clinica();
//				Date medico1=new Date(12/12/1957);
//				Amministratore amministratore = new Amministratore("@hotmail.it","123","Mario","Rossi",medico1);

//				Date medico22=new Date(5/1/1950);
//				Date esame1p=new Date(21/6/2012);
//				Date esame2p=new Date(12/7/2016);
//				Date esame1=new Date(30/12/2012);
//				Date esame22=new Date(5/10/2016);
		//	
//				
//				Medico medico = new Medico("Mario","Rossi","123sadsa","@fuk","vigje",medico1);
//				Medico medico2 = new Medico("Paolo","Merialdo","123sadsa","@silver","poska",medico22);
//				
				Prerequisito digiuno = new Prerequisito("digiuno12","il paziente si deve presentare a digiuno da almeno 12 ore");
				Indicatore indicatore1 = new Indicatore("colesterolo ldl");
				Indicatore indicatore2 = new Indicatore("colesterolo hdl");
				Indicatore indicatore3 = new Indicatore("colesterolo totale");
				
				TipologiaEsame esameDelSangue = new TipologiaEsame("esame Del Sangue","prelievo del sangue al braccio" , 45);
				esameDelSangue.addPrerequisito(digiuno);
				esameDelSangue.addIndicatore(indicatore1);
				esameDelSangue.addIndicatore(indicatore2);
				esameDelSangue.addIndicatore(indicatore3);
				
				TipologiaEsame esameDelleUrine = new TipologiaEsame("esame Delle urine","esame su un campione di urine" , 15);
				esameDelleUrine.addPrerequisito(digiuno);
				esameDelleUrine.addIndicatore(indicatore1);
				esameDelleUrine.addIndicatore(indicatore2);
				esameDelleUrine.addIndicatore(indicatore3);
//				
//				Esame esame = new Esame(esame1p,esame1,medico,esameDelSangue);
//				Esame esame2 = new Esame(esame2p,esame22,medico2,esameDelleUrine);
				
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("products-unit");
				EntityManager em = emf.createEntityManager();
//				AmministratoreDao amministratoreDao=new AmministratoreDao(em);
//				amministratoreDao.save(amministratore);
//				EsameDao esameDao = new EsameDao(em);
//				MedicoDao medicoDao = new MedicoDao(em);
//				medicoDao.save(medico);
//				medicoDao.save(medico2);
//				esameDao.save(esame);
//				esameDao.save(esame2);
				TipologiaEsameDao tipologiaEsameDao = new TipologiaEsameDao(em);
				tipologiaEsameDao.save(esameDelSangue);
				tipologiaEsameDao.save(esameDelleUrine);
		//////	
////			    
////			    clinica.getTipologieEsami().addAll(tipologiaEsameDao.findAll());
////			    System.out.println(clinica.getTipologieEsami().size());
			    em.close();
			    emf.close();
//			    System.out.println(NamedQuery.class.getProtectionDomain().getCodeSource().getLocation());
//				
//				/*Calendar calendar = Calendar.getInstance();
//				Date data = calendar.getTime();
//				Paziente paziente = new Paziente("ugo", "verdi", "1111", "ugo@gmail.com", "ugovrd45r501e", data);
//				PazienteDao pazienteDao = new PazienteDao(em);
//				pazienteDao.save(paziente);
//				em.close();
//				emf.close();
//				//System.out.println((pazienteDao.findByCodiceFiscale("ugovrd45r501e").toString()));
//			    	}*/
			}
}
		
//		
//		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("products-unit");
//		EntityManager entityManager = entityManagerFactory.createEntityManager();
//		
//		//Medico medico  = new MedicoDao(entityManager).findById(1);
//		
//		//String s = "dott "+medico.getNome()+" "+medico.getCognome()+" "+medico.getEmail();
////		String uno = s.substring(0, s.indexOf(':')-1);
////		String due = s.substring(s.indexOf(':')+2);
//
//		//String mail = s.substring(s.lastIndexOf(" ")+1);
////		Medico medicoCorrente = new Helper().getMedicoCorrente(mail, entityManager);
//		
////		System.out.println(medicoCorrente.toString());
//		Paziente paziente = new PazienteDao(entityManager).findByMail("ugo@gmail.com");
//		Medico medico=null;
//		System.out.println(paziente);
//	}
//
//}
