package model;

public class Portale {
	
	
	private Clinica clinica;
	
	
	
	public Portale(Clinica clinica) {
		super();
		this.clinica = clinica;
	}
	
	//getter and setter

	public Clinica getClinica() {
		return clinica;
	}
	public void setClinica(Clinica clinica) {
		this.clinica = clinica;
	}
	
	
	
	
	


	
}
